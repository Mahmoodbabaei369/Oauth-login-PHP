<?php require 'config.php'; ?>  
<!DOCTYPE html>
<html>
<head>
    <title>Login with google</title>
</head>
<body>
    <h2>OAuth Login</h2>
    <h4>click below to login with google</h4>
    <a href="google-callback.php">
        <img src="https://developers.google.com/identity/images/btn_google_signin_dark_normal_web.png">
    </a>
    <br><br>
</body>
</html>